<?php
<!doctype html>
<html lang="en">


<head>
 <meta charset="utf-8">
	<title>JET GAME</title>
	<link rel="stylesheet" href="game.css">

</head >
<body bgcolor="grey">
	<button type="button"  id="startbtn"  bgcolor="white" >start</button>
<canvas id="canvasBg" width="800" height="500" style="background:#ffffff;">   </canvas>
<canvas id="canvasjet" width="800" height="500" ></canvas>
<canvas id="canvasenemy" width="800" height="500" ></canvas>
<canvas id="canvashud" width="800" height="500" ></canvas>

<script type="text/javascript" src="game.js">

</script>


</body>


</html>
?>