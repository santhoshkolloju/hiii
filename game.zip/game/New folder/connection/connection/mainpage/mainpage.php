<?php session_start(); 
include "../dbconnecct.php";

?>
<html>
<head>
<link rel="stylesheet" href="mainpage.css"/>
</head>
<body>
<div id="optionsdiv" >
<form name="options" action="<?php echo $_SERVER['SCRIPT_NAME']; ?>" method="get">
<?php 
$conn=setconnection($_SESSION["servername"],$_SESSION["uname"],$_SESSION["pwd"],$_SESSION["database"]);
$query="show tables from ".$_SESSION["database"]."";
if($res=mysql_query($query,$conn))
{
$nrows=mysql_num_rows($res);
if($nrows==0)
echo "No Tables in DataBase....";
else
{
echo "<select id='dbselect' name='dbselect' >";

while($row=mysql_fetch_array($res))
echo "<option value={$row[0]} >{$row[0]}</option>";

echo "</select><br/>";

$queryc="show columns from ".$_GET["dbselect"]."";
if($colres=mysql_query($queryc,$conn))
{
$nclms=mysql_num_rows($colres);
echo "<h2>".$_GET["dbselect"]."</h2>";
while($cols=mysql_fetch_array($colres))
{
echo "<input type='checkbox' value={$cols[0]}/> {$cols[0]} </br>";
}
}
}
}
?>



<input type="submit" value="go" name="go" onclick="cols()"/>


</form> 

</div>
<div id="tablediv">
<div id="tableelements">
<?php
$querytable="select * from ".$_GET['dbselect']." ";

if($tableres=mysql_query($querytable,$conn))
{
$colres=mysql_query($queryc,$conn);
echo "<table id='restable' border=5>";
echo "<tr>";
while($cols=mysql_fetch_array($colres))
{

echo "<th>{$cols[0]}</th>";

}
echo "</tr>";
while($tablerow=mysql_fetch_array($tableres))
{
echo "<tr>";
for($i=0;$i<$nclms;$i++)
{
echo "<td>{$tablerow[$i]}</td>";

}
echo "</tr>";

}
echo "</table>";
}
?>

</div>


</div>
</body>
</html>
